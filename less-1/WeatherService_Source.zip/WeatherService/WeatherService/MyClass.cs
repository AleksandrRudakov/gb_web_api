﻿namespace WeatherService
{
    public class MyClass
    {
    }
}
